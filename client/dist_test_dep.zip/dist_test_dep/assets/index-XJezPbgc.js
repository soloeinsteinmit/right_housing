import{d as a}from"./index-CRywKuyh.js";var r=a;export{r as default};
